<?php
    //After turning on SQL on XAMPP, you can manage the DB via this url:
    // http://localhost/phpmyadmin
    
    // Database connection
    $servername = "localhost";
    $username = "root"; // Change if necessary
    $password = ""; // Change if necessary
    $dbname = "itmosys_db";
?>