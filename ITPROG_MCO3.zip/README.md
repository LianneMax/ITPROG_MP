# ITmosys Course Enrollment System
This project is developed as a requirement of IT-PROG

# Project Overview:
The ITmosys system will manage IT student accounts, class schedules, and enrollment. The database will contain only IT subject codes along with their respective professors and schedules.

# Running the DB Script
1. Under the /sqlmodels subfolder, find the itmosys_db_V10.sql file
2. Open the file in any text editor, then copy all its contents 
3. Open XAMPP Control panel, then [Start] the MySQL service
4. Once the service started, press the [Admin] button
5. After you're redirected to the admin page on your browser, click [SQL] on the top of the screen
6. Paste the sql file contents in the text box, then press [Go] on the bottom right
7. Now the itmosys_db schema should be visible on the left side.

## Authors
- Jeremiah Maxwell Ang
- Lianne Maxene Balbastro
- Charles Kevin Duelas
- Justin Nicolai Lee